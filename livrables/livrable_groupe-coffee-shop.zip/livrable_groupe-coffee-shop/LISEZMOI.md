# Livrable — groupe-coffee-shop

Modèle de base : `Qwen/Qwen3-0.6B` (révision `c1899de289a04d12100db370d81485cdf75e47ca`)
Adaptateur LoRA : `adaptateur/` (2.3 Mo, float16)
Run MLflow : `lora 250 pas` (1e73e0ad4648410aad52df1e4f7c0626)

| mesure | validation | test |
|---|---|---|
| intent_acc (LoRA) | 83% | 67% |
| exact (LoRA) | 58% | 46% |
| intent_acc (base+prompt) | — | 0% |

Porte de qualité : FAIL
Lectures du test pendant le projet : 3
Notes du groupe : donnees/NOTES.md

Pour évaluer ce livrable (le modèle de base est téléchargé automatiquement) :

    uv run python evaluer_livrable.py livrable_groupe-coffee-shop.zip
    uv run python evaluer_livrable.py livrable_groupe-coffee-shop.zip --demo
